Developer: Scott Westover

This component was built using the information from the following websites:

http://www.x3dom.org/

I built the component to use x3d files and display them on your website.

All files should be in the .x3d format.

The component will just display an empty box with a border until you choose
a file in the dialog box. If you choose a file that is not in the x3d format
than the component will not work.